const isIranMobileRegex = /^09[0-9]{9}$/;
module.exports = isIranMobileRegex;
