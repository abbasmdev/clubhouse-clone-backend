const profileImageUpload = require("./profile-image.upload");

const multerUploads = {
  profileImageUpload,
};
module.exports = multerUploads;
