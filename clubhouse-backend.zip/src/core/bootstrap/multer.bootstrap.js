class MulterBootstrap {
  async init() {
    console.log(`MulterBootstrap success.`);
  }
}

const multerBootstrap = new MulterBootstrap();
module.exports = multerBootstrap;
