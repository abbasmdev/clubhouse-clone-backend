const apiControllers = {
  apiAuthController: require("./auth.controller"),
};

module.exports = apiControllers;
